export type StarterModuleKey = "core-auth" | "orgs" | "crm" | "marketing" | "projects" | "admin";

export type StarterModuleConfig = {
  key: StarterModuleKey;
  label: string;
  description: string;
  enabled: boolean;
  packageName: string;
  routeHref?: string;
  placement: "core" | "primary" | "admin" | "hidden";
};

export const starterModuleConfig: StarterModuleConfig[] = [
  {
    key: "core-auth",
    label: "Core Auth",
    description: "Login, reset-password, callback URLs, and shared auth validation utilities.",
    enabled: true,
    packageName: "@brightweblabs/core-auth",
    placement: "core",
  },
  {
    key: "orgs",
    label: "Organizations",
    description: "Shared organizations, membership, and invitation foundation for CRM, Marketing, and Projects.",
    enabled: true,
    packageName: "@brightweblabs/module-orgs",
    placement: "hidden",
  },
  {
    key: "crm",
    label: "CRM",
    description: "Contacts and CRM server/data layer, with marketing-adjacent operational data stored in Supabase.",
    enabled: true,
    packageName: "@brightweblabs/module-crm",
    routeHref: "/crm",
    placement: "primary",
  },
  {
    key: "marketing",
    label: "Marketing",
    description: "Consent-first campaigns, segments, analytics, and automated email workflows.",
    enabled: true,
    packageName: "@brightweblabs/module-marketing",
    routeHref: "/marketing",
    placement: "primary",
  },
  {
    key: "projects",
    label: "Projects",
    description: "Project portfolio, detail routes, and work-management server logic.",
    enabled: true,
    packageName: "@brightweblabs/module-projects",
    routeHref: "/projetos",
    placement: "primary",
  },
  {
    key: "admin",
    label: "Admin",
    description: "User role governance, admin tools, and access-control surfaces.",
    enabled: true,
    packageName: "@brightweblabs/module-admin",
    routeHref: "/admin/users",
    placement: "admin",
  },
];

export function getEnabledStarterModules() {
  return starterModuleConfig.filter((moduleConfig) => moduleConfig.enabled);
}
