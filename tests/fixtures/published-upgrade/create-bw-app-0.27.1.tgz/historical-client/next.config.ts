import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: [
    "@brightweblabs/app-shell",
    "@brightweblabs/core-auth",
    "@brightweblabs/infra",
    "@brightweblabs/theme",
    "@brightweblabs/ui",
    "@brightweblabs/module-orgs",
    "@brightweblabs/module-crm",
    "@brightweblabs/module-marketing",
    "@brightweblabs/module-projects",
    "@brightweblabs/module-admin",
  ],
};

export default nextConfig;
