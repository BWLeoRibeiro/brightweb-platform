# Historical Client

Project scaffolded with create-bw-app.

## Local setup

1. Review `.env.local` and fill in real service credentials.
2. Run `pnpm install`.
3. Link the Supabase project and run `supabase db push`.
4. Run `bw admin create --email you@example.com` to create the first administrator.
5. Run `pnpm dev`.

## Enabled modules

- crm: enabled
- marketing: enabled
- projects: enabled
- admin: enabled

## Resolved database stack

- Core
- Admin
- Orgs
- CRM
- Marketing
- Projects

Bundled Supabase SQL migrations live under `supabase/modules/<module>/migrations`.

## Dependency notes

- Organizations is included because CRM, Marketing, Projects depends on it.

## First administrator

Run `bw admin create --email you@example.com` after the generated migrations and `.env.local` values are in place.
The command refuses projects that already contain an admin unless `--force` is explicit, refuses to promote an existing Auth user, never accepts a password, and sends the new user through the Core Auth `/reset-password` flow.

## Function region

<!-- vercel.json region placeholder: once the Supabase region is known, set SUPABASE_PROJECT_REGION and add the nearest verified Vercel region as `"regions": ["<region>"]`. -->
Keep `SUPABASE_PROJECT_REGION` current if the Supabase project is replaced, then run `bw doctor --deployment-url https://your-app.example` to compare it with the deployed Vercel Function region.

## Package mounts

- `/login`
- `/forgot-password`
- `/reset-password`
- `/account`
- `/dashboard`
- `/admin/users`
- `/crm`
- `/marketing`
- `/projetos`
- `/account/projetos`

## AI handoff

- `AGENTS.md`
- `docs/ai/README.md`
- `docs/ai/examples.md`
- `docs/ai/app-context.json`
