export { marketingCampaignRecipientsGet as GET } from "../../../_handlers";
export const dynamic = "force-dynamic";
