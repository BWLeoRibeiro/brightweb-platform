import type { ReactNode } from "react";
import { requireServerPageAccess } from "@brightweblabs/core-auth/server";
import { ShellLayoutClient, type ShellViewer } from "./shell-layout-client";

export const dynamic = "force-dynamic";

export default async function ShellLayout({ children }: Readonly<{ children: ReactNode }>) {
  const { profileId, supabase, user, role } = await requireServerPageAccess();
  const { data: profile } = await supabase
    .from("profiles")
    .select("first_name, last_name")
    .eq("user_id", user.id)
    .maybeSingle<{ first_name: string | null; last_name: string | null }>();

  const viewer: ShellViewer = {
    profileId,
    email: user.email ?? null,
    firstName: profile?.first_name ?? null,
    lastName: profile?.last_name ?? null,
    isAdmin: role === "admin",
    isStaff: role === "staff" || role === "admin",
  };

  return <ShellLayoutClient viewer={viewer}>{children}</ShellLayoutClient>;
}
