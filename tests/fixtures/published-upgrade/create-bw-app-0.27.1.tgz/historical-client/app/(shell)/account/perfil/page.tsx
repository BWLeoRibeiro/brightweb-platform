export default function ClientProfile() { return <main>Historical client customization</main>; }
